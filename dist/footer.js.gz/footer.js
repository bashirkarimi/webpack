(self["webpackChunkwebpack"] = self["webpackChunkwebpack"] || []).push([["footer"],{

/***/ "./src/assets/js/footer.js":
/*!*********************************!*\
  !*** ./src/assets/js/footer.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "footer": () => (/* binding */ footer)
/* harmony export */ });
var footer = document.createElement('footer');
footer.innerHTML = 'footer';
footer.style.color = 'green';


/***/ })

}]);
//# sourceMappingURL=footer.js.map